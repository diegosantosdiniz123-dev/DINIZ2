document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("formLogin");

    form.addEventListener("submit", function(event){
        event.preventDefault();

        let email = document.getElementById("emailLogin").value.trim();
        let senha = document.getElementById("senhaLogin").value.trim();

        // verificar campos vazios
        if(email === "" || senha === ""){
            alert("Preencha todos os campos!");
            return;
        }

        // pegar dados salvos
        let emailSalvo = localStorage.getItem("email");
        let senhaSalva = localStorage.getItem("senha");

        // validar login
        if(email === emailSalvo && senha === senhaSalva){
            alert("Login realizado com sucesso!");

            // redireciona
            window.location.href = "index.html";
        } else {
            alert("Email ou senha incorretos!");
        }
    });

});