document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("formCadastro");

    form.addEventListener("submit", function(event){
        event.preventDefault();

        let email = document.getElementById("email").value.trim();
        let senha = document.getElementById("senha").value.trim();
        let confirmar = document.getElementById("confirmar").value.trim();

        // validar campos
        if(email === "" || senha === "" || confirmar === ""){
            alert("Preencha todos os campos!");
            return;
        }

        if(senha.length < 6){
            alert("A senha deve ter no mínimo 6 caracteres!");
            return;
        }

        if(senha !== confirmar){
            alert("As senhas não coincidem!");
            return;
        }

        // salvar dados
        localStorage.setItem("email", email);
        localStorage.setItem("senha", senha);

        alert("Conta criada com sucesso!");

        // redirecionar
        window.location.href = "verificacao.html";
    });

});