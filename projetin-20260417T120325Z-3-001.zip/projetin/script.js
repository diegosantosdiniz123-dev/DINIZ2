// ================= PETS =================
const pets = [
    { nome: "Bruno", raca: "SRD", cidade: "São Paulo" },
    { nome: "Tobias", raca: "Siames", cidade: "Rio de Janeiro" },
    { nome: "Mel", raca: "Golden Retriever", cidade: "Belo Horizonte" },
    { nome: "Thor", raca: "SRD", cidade: "Curitiba" }
];

// ================= EXIBIR PETS =================
function exibirPets(lista) {

    const container = document.getElementById("listaPets");
    const mensagem = document.getElementById("mensagem");

    if (!container) return; // evita erro em outras páginas

    container.innerHTML = "";

    if (lista.length === 0) {
        if (mensagem) {
            mensagem.innerText = "Nenhum pet encontrado ou cadastrado com esse nome 😿";
        }
        return;
    }

    if (mensagem) mensagem.innerText = "";

    lista.forEach(pet => {
        container.innerHTML += `
        <div class="card">
            <h3>${pet.nome}</h3>
            <p>${pet.raca}</p>
            <p>${pet.cidade}</p>

            <button class="btn-details">Ver detalhes</button>
            <button class="btn-contact">Contato</button>
        </div>
        `;
    });
}

// ================= BUSCAR =================
function buscarPets() {

    const input = document.getElementById("searchInput");
    if (!input) return;

    const texto = input.value.toLowerCase().trim();

    const filtrados = pets.filter(p =>
        p.nome.toLowerCase().includes(texto) ||
        p.raca.toLowerCase().includes(texto) ||
        p.cidade.toLowerCase().includes(texto)
    );

    exibirPets(filtrados);
}

// ================= EVENTOS =================
document.addEventListener("DOMContentLoaded", () => {

    // botão buscar
    const btnBuscar = document.getElementById("btnBuscar");
    if (btnBuscar) {
        btnBuscar.addEventListener("click", buscarPets);
    }

    // ENTER no input
    const input = document.getElementById("searchInput");
    if (input) {
        input.addEventListener("keypress", (event) => {
            if (event.key === "Enter") {
                buscarPets();
            }
        });
    }

    // mostrar pets ao carregar
    exibirPets(pets);

    // BOTÕES PRINCIPAIS
    const botao1 = document.getElementById("botao1");
    if (botao1) {
        botao1.addEventListener("click", () => {
            window.location.href = "perdidos.html";
        });
    }

    const botao2 = document.getElementById("botao2");
    if (botao2) {
        botao2.addEventListener("click", () => {
            window.location.href = "encontrados.html";
        });
    }

});